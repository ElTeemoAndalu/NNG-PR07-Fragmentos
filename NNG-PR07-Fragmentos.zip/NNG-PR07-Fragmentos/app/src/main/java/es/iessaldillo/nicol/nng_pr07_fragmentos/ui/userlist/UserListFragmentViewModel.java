package es.iessaldillo.nicol.nng_pr07_fragmentos.ui.userlist;

import android.arch.lifecycle.ViewModel;

public class UserListFragmentViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
